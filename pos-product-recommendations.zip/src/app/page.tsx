"use client";

import React from "react";

export default function POSPage() {
  return <div>Hello POS!</div>;
}
