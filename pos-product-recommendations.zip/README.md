# POS Product Recommendations

A POS interface built with React, Tailwind CSS, Framer Motion, and Radix UI Tabs.

## Setup

1. Clone the repo
2. Run `npm install`
3. Run `npm run dev`
